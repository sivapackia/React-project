import React from "react";
import { BrowserRouter, Route,Routes } from "react-router-dom";
import Home from "./Home/Home";
import Component from "./Component/Component";
import Detail from "./Detail/Detail"
import Gallery from "./Gallery/Gallery";
import Mobilehome from "./Mobile/Mobile";


const Rout=()=>{

    return(

        <BrowserRouter>
        
        <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path="/Component" element={<Component/>}></Route>
            <Route path="/Detail" element={<Detail/>}></Route>
            <Route path="/Gallery" element={<Gallery/>}></Route>
            <Route path="/Mobile" element={<Mobilehome/>}></Route>
        </Routes>
        </BrowserRouter>
    )
}

export default Rout