import { createSlice } from "@reduxjs/toolkit";
import User from './Main.json';


export const Slice=createSlice(
    {
        name:"magicbrick",

        initialState:{
            Array:User.town,
            Arrayone:User.Explore,       
            isProperty:[],
            Arraytwo:User.Gallery
            // flatt:"",
            // budgett:""
        },
        reducers:{
            updateProperty:(state,action)=>{
                state.isProperty = action.payload
            },
            Component:(state,action)=>{
                state.Array = action.payload
            },
            Detail:(state,action)=>{
                state.Array = action.payload
            },
            Flatupdate:(state,action)=>{
                state.isFlat = action.payload
               
            },
            Budgetmin:(state,action)=>{
                state.isBudget = action.payload
            },
            Budgetmax:(state,action)=>{
                state.isBudgetmax = action.payload
            }
            // console.log(isFlat)

        }
    }
)

export default Slice.reducer
export const {Flatupdate,updateProperty}=Slice.actions