import React from "react";
import { Navbar } from "./Navbar/Navbar";
import Banner from "./Banner/Banner";


const Detail=()=>{
    return(
        <>
        <Navbar/>
        <Banner/>
        </>
    )
}

export default Detail