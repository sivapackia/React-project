import React from "react";
import Mobile from "./Home/Home";


const Mobilehome=()=>{
    return(
        <>
        <Mobile/>
        </>
    )
}

export default Mobilehome